<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SalarySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
//        DB::table('salaries')->insert([
//            'employee_id' => 1,
//            'user_id' => 31,
//            'salary' => random(5,50000),
//            'start_date' => random(5,2021-02-01),
//            'start_date' => random(5,2021-02-28),
//            'working_days' => random(5,28),
//            'absent_days' => random(5,0)
//        ]);
    }
}
