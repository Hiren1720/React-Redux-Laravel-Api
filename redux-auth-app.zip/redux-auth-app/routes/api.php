<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Auth\EmployeeLoginController;
use App\Http\Controllers\EmployeesController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\EventController;
use App\Http\Controllers\PasswordController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\SalaryController;
use App\Models\Employee;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Str;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


Route::post('user/login',[LoginController::class,'login']);
Route::post('user/register',[RegisterController::class,'register']);
Route::post('/user/password/requestEmail',[PasswordController::class,'requestEmail']);
Route::post('/user/password/resetPassword',[PasswordController::class,'resetPassword']);
//Route::get('user/profile/',[ProfileController::class,'profile']);
Route::group(['middleware'=>'auth:api'],function (){
    Route::get('/user', function (Request $request) {
        // dd($request);
        $user = $request->user();
        $employees = User::find($user->id)->Employee;
        $salary = User::find($user->id)->Salary;
        $countSalary = count($salary);
        $countEmployees = count($employees);
        $partners = User::all();
        $totalPartners = count($partners);
        return response()->json([
            "user" => $user,
            "employees" => $countEmployees,
            "Partners" => $totalPartners
          ]);
    });


    Route::put('user/update',[HomeController::class,'update']);

    Route::get('/employee',[EmployeesController::class,'index']);
    Route::get('/employee/all',[EmployeesController::class,'all']);
    Route::post('/employee/store',[EmployeesController::class,'store']);
    Route::get('/employee/edit/{id}',[EmployeesController::class,'edit']);
    Route::get('/salary/report/{id}',[EmployeesController::class,'show']);
    Route::post('/employee/update/{id}',[EmployeesController::class,'update']);
    Route::delete('/employee/delete/{id}',[EmployeesController::class,'destroy']);

    Route::get('/salary',[SalaryController::class,'getAll']);
    Route::post('/salary/search',[SalaryController::class,'index']);
    Route::post('/salary/store/{id}',[SalaryController::class,'store']);
    Route::get('/salary/edit/{id}',[SalaryController::class,'edit']);
    Route::post('/salary/update/{id}',[SalaryController::class,'update']);
    Route::delete('/salary/delete/{id}',[SalaryController::class,'destroy']);

    Route::get("/event",[EventController::class,'index']);
    Route::post("/event/store",[EventController::class,'store']);
    Route::get("/event/edit/{id}",[EventController::class,'edit']);
    Route::post("/event/update/{id}",[EventController::class,'update']);
    Route::delete("/event/destroy/{id}",[EventController::class,'destroy']);

});


