<?php

use App\Http\Controllers\Auth\EmployeeLoginController;
use App\Http\Controllers\EmployeeSalaryController;
use App\Http\Controllers\EmployeesController;

use App\Http\Controllers\HomeController;
use App\Http\Controllers\SalaryController;
use App\Models\Employee;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Str;

Route::post('/employee/login',[EmployeeLoginController::class,'employeeLogin']);
Route::group(['middleware' => ['auth:employee']], function() {
    Route::get('/home', [HomeController::class, 'index'])->name('home');
    Route::get('/employee',[HomeController::class, 'self']);
    Route::get('/employee/salary',[EmployeeSalaryController::class,'salary']);
});
