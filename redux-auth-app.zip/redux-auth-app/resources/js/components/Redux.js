import React from 'react';
import ReactDOM from 'react-dom';

function Redux() {
    return (
        <div className="container">
            <div className="row justify-content-center">
                <div className="col-md-8">
                    <div className="card">
                        <div className="card-header">Redux Example Component</div>

                        <div className="card-body">I'm an Redux example component!</div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Redux;

if (document.getElementById('redux')) {
    ReactDOM.render(<Redux />, document.getElementById('redux'));
}
