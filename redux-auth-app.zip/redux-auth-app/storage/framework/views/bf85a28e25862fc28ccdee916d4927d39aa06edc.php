<?php echo e($slot); ?>

<?php /**PATH /home/admin-pc-3/Home/Hiren/redux-auth-app/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>