<?php

namespace App\Http\Controllers\Auth;

use App\Events\Userlogin;
use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use http\Env\Response;
use HttpException;
use App\Models\User;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use function PHPUnit\Framework\returnArgument;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }
    public function login(Request $request)
    {
        // $input = $request->only(['email', 'password']);
        // dd($request);
        $credentials = Auth::guard()->attempt(["email" => $request->email,"password" => $request->password]);
        // dd($credentials);
        if($credentials == true){
            $user = User::where('email',$request->email)->first();

            if($user){
//                if( !Hash::check($request->password, $user->password)){
//                    return response()->json(["message" => "Your Password Is Incorrect"]);
//                }

                $token = $user->createToken('authToken')->accessToken;

                return response()->json([
                    "user"=>$user,
                    "type" => $request->type,
                    "token"=> $token
                ]);
            }else{
                return response()->json([
                   "error"=>"User Not Found"
                ]);
            }

        }else{
            return response()->json([
                "message"=>"Login Failed"
            ]);
        }
        event($event= new Userlogin($request->email));
        $to_name = $request->name;
        $to_email = $request->email;
        $data = array('name' => 'Hiii..','body'=>'You are Login');
        $mail = Mail::send('mail',$data,function ($message) use ($to_name,$to_email){
            $message->to($to_email);
            $message->subject('Account Login');
        });


    }
}
///home/admin-pc-3/.nvm/versions/node/v16.3.0/bin:/home/admin-pc-3/Home/Hiren/redux-auth-app/node_modules/.bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games
