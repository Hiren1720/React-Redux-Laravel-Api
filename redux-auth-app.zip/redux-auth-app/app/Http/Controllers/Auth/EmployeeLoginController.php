<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use App\Models\Employee;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;

class EmployeeLoginController extends Controller
{
    use AuthenticatesUsers;
    protected $redirectTo = RouteServiceProvider::HOME;
    public function __construct()
    {
        $this->middleware('guest:employee')->except('logout');
    }
    // public function showLoginForm()
    // {
    //     return view('auth.login.employees');
    // }
//    public function username()
//    {
//        return 'email';
//    }
    protected function guard()
    {
        return Auth::guard('employee');
    }
    public function employeeLogin(Request $request)
    {

            $employee = Employee::where('email',$request->email)->first();

            if($employee){
                if( !Hash::check($request->password, $employee->password)){
                    return response()->json(["message" => "Your Password Is Incorrect"]);
                }
                $token = $employee->createToken('authToken')->accessToken;

                return response()->json([
                    "type" => $request->type,
                    "token"=> $token,

                ]);
            }else{
                return response()->json([
                   "error"=>"Employee Not Found"
                ]);
            }



    }

}
