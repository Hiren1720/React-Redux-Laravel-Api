<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class PasswordController extends Controller
{
    public function requestEmail(Request $request){
//        dd($request->email);
        $user = User::where('email',$request->email)->first();

        if($user){
            return response()->json([
               "responseEmail" => $user->email,
                "Success" => "Success"
            ]);
        }else{
            return response()->json([
                "Success" => "Invalid"
            ]);
        }
    }
    public function resetPassword(Request $request){
        $user = User::where('email',$request->email)->first();
        if($user) {
            $user->password =  Hash::make($request->password);
            $password = $user->save();
            if ($password) {
                return response()->json([
                    "success" => "success"
                ]);
            } else {
                return response()->json([
                    "success" => "Password not Update"
                ]);
            }
        }
    }
}
