<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Repositories\SalaryRepositoryInterface;
use Illuminate\Http\Request;
use App\Models\Salary;
class SalaryController extends Controller
{
    /**
     * @var SalaryRepositoryInterface
     */
    protected $salaryRepo;

    /**
     * SalaryController constructor.
     * @param SalaryRepositoryInterface $salary
     */
    public function __construct(SalaryRepositoryInterface $salary)
    {
        $this->salaryRepo = $salary;

    }

    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return void
     */
    public function index(Request $request)
    {
//        dd($request);
        $salary =  $this->salaryRepo->index($request->all());
        if($salary){
            return response()->json([
                "salary" => $salary
             ]);
        }
        else{
            return response()->json([
                "error" => "Records Not Found"
             ]);
        }
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param $id
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request,$id)
    {
        $addSalary = $this->salaryRepo->store($request->all(),$id);
       if($addSalary){
        return response()->json(
            "success"
        );
       }else{
        return response()->json(
            "Error"
        );
       }
        
    }

    public function getAll(){
        $salary =  $this->salaryRepo->getAll();
        if($salary){
            return response()->json([
                "salary" => $salary
             ]);
        }
        else{
            return response()->json([
                "error" => "Records Not Found"
             ]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $salary = $this->salaryRepo->edit($id);
//        dd($salary);
        if($salary){
            return $salary;
        }else{
            return response()->json([
                "message"=>"Salary Not Found"
            ],404);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
//        dd($this->salaryRepo->update());
        $salary = $this->salaryRepo->update($id,$request->all());
        if($salary){
            return response()->json(
                "success"
            );
        }else{
            return response()->json([
                "message"=>"Employee Not Found"
            ],404);
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $salary = $this->salaryRepo->destroy($id);
//        dd($salary);
        $salary = Employee::find($salary->employee_id)->salary;
        return  response()->json([
            "salary" => $salary,
        ]);
    }
}
