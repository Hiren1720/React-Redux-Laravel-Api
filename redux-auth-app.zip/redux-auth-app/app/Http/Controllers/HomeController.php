<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }
    public function self(Request $request){

        $employee = $request->user();
        $user = User::find($employee->user_id);
        $senior = $user->name;

        $salary = Employee::find($employee->id)->salary;
//        dd($salary);
        return response()->json([
            "employee" => $employee,
            "senior"=>$senior
        ]);
    }
    public function update(Request $request){
//        dd($request->user());
        $user = $request->user();

            $accessToken = $user->createToken('authToken')->accessToken;
            $user->name = $request->name;
            $user->email = $request->email;

            $user->save();
            if($user){
                return response()->json([
                    'status' => 'Ok',
                    'user' => $user,
                    'token' => $accessToken,
                ]);
            }else{
                return response()->json([
                    'message' => "Update Request Failed",
                ]);
            }

    }

}
