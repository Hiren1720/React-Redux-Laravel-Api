<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\User;
use Illuminate\Http\Request;

class EmployeeSalaryController extends Controller
{
    public function salary(Request $request){
        $employee = $request->user();
        $salary = Employee::find($employee->id)->salary;
        return  response()->json([
            "salary" => $salary,
        ]);
    }
}
