<?php

namespace App\Http\Controllers;

use App\Models\Employee;

use App\Models\User;
use App\Repositories\SalaryRepositoryInterface;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class EmployeesController extends Controller
{
    // public function __construct()
    // {
    //     $this->middleware('auth:api-employees');
    // }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $perPage = $request['perPage'] ?? 2 ;
//        dd($perPage);

        $user = $request->user();
        // $emp = Employee::where('user_id',$user->id);
        $employees = Employee::where('user_id',$user->id)->paginate($perPage);
//        $page = $employees->paginate($perPage);

        $totalEmp = Employee::all();

        $totalEmployees = count($totalEmp);
        $countEmployees = count($employees);
          return  response()->json([
              "employees" => $employees,
              "countEmployees" => $countEmployees,
              "totalEmployees" => $totalEmployees,

          ]) ;

    }
   public function all(Request $request)
   {
       $user = $request->user();
    //    dd($user);
       $per_page = $request['per_page'] ?? 5 ;
       $EmployeesAll = Employee::all();
       $employees = User::find($user->id)->Employee;
       $totalEmp = Employee::with("User")->paginate($per_page);
        $totalEmployees = count($EmployeesAll);
        $countEmployees = count($employees);
       
       return  response()->json([
           "employees" => $totalEmp,
           "countEmployees" => $countEmployees,
           "totalEmployees" => $totalEmployees,
           "user" => $user
       ]) ;

   }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $user = $request->user();
//        $employeeAdded = Employee::where("email",$request->email)->first();
//        if($employeeAdded->email == $request->email){
//            return response()->json([
//                "errors" => "This Email is Already Exists"
//            ]);
//        }elseif ($employeeAdded->phone == $request->phone){
//            return response()->json([
//                "errors" => "This Phone Number is Already Exists"
//            ]);
//        }else{
        $image = $request->profile;
        $extension = $image->getClientOriginalExtension();
        $random_name = Str::random(5,"abcde");
        $random_image = $random_name.'.'.$extension;
//        $image_name = $image->getClientOriginalname();
        $destination_path = 'public/images';
        $path = $request->profile->storeAs($destination_path,$random_image);
        $employeeCreate = new Employee ([
            'name' =>$request->name,
            'role' => $request->role,
            'email' => $request->email,
            'password' =>  Hash::make($request->password),
            'phone' => $request->phone,
            'birthdate' => $request->birthdate,
            'gender' => $request->gender,
            'hobby' => $request->hobby,
            'profile' => $random_image,
            'city' => $request->city,
            'address' =>$request->address,
            'user_id' => $user->id,
        ]);
        $employeeCreate->save();
        return response()->json(
            $employeeCreate
        );
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

        $salary = Employee::find($id)->salary;

        return  response()->json([
            "salary" => $salary,

        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $employee = Employee::find($id);

        if($employee){
            return $employee;
        }else{
            return response()->json([
                "message"=>"Employee Not Found"
            ],404);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function update(Request $request,$id){
//        if($request){
//            dd($request->all());
//        }
        if(Employee::where('id',$id)->exists()){
//            $employeeAdded = Employee::where("email",$request->email)->first();
//            if($employeeAdded->email == $request->email){
//                return response()->json([
//                    "errors" => "This Email is Already Exists"
//                ]);
//            }elseif ($employeeAdded->phone == $request->phone){
//                return response()->json([
//                    "errors" => "This Phone Number is Already Exists"
//                ]);
//            }else{
                $employee = Employee::find($id);
                $oldPassword = $employee->password;
                $oldprofile = $employee->profile;
                if($request->profile){
                    $image = $request->profile;
                    $extension = $image->getClientOriginalExtension();
                    $random_name = Str::random(5,"abcde");
                    $oldprofile = $random_name.'.'.$extension;
                    $destination_path = 'public/images';
                    $path = $request->profile->storeAs($destination_path,$oldprofile);
                }

                $employee->name = $request->name;
                $employee->role = $request->role;
                $employee->email = $request->email;
                $employee->password =  $oldPassword ;
                $employee->phone = $request->phone;
                $employee->gender = $request->gender;
                $employee->hobby = $request->hobby;
                $employee->profile = $oldprofile;
                $employee->city = $request->city;
                $employee->address = $request->address;
                $employee->save();
                return response()->json($employee);

        }else{
            return response()->json([
                "message"=>"Employee Not Found"
            ],404);
        }
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
//        Employee::destroy(collect(request()->all()));
        $employee = Employee::find($id);
        $employee->delete();
        $user = $request->user();
        $employees = User::find($user->id)->employees;
        return $employees;
    }
}
