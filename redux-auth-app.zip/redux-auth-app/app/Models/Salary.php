<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Salary extends Model
{
    use HasFactory;
    protected $fillable = ['employee_id','user_id','salary','month','start_date','end_date','working_days','absent_days'];
    public function Employee(){
        return $this->belongsTo(Employee::class);
    }
    public function User(){
        return $this->belongsTo(User::class);
    }
    // protected $appends=['name_salary'];
    // public function getNameSalaryAttribute(){
    //     return $this->->employees();
    // }

}
