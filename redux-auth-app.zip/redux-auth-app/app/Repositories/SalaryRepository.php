<?php
namespace App\Repositories;



use App\Models\Employee;
use App\Models\Salary;
use Illuminate\Support\Facades\Auth;

class SalaryRepository implements SalaryRepositoryInterface
{
    /**
     * @param array $data
     * @return mixed|void
     */
    public function index(array $data)
    {
//         dd($data);
        $employee = Employee::where('name',$data['name'])->first();
        $salary = Salary->where('employee_id',$employee->id);
        return $salary;
    }

    public function create()
    {
        // TODO: Implement create() method.
    }
    public function getAll(){
        $salary = Salary::with('Employee')->with('User')->get();
        // $salary = Salary::all();
        // dd($salary);
        return $salary;
    }
    public function store(array $data,$id )
    {

        $user = Auth::user();
        $user_id = $user->id;
//        dd($data['salary']);
        $addSalary = new Salary ([
            'employee_id' =>$id,
            'user_id' => $user_id,
            'salary' => $data['salary'],
            'month' => $data['month'],
            'start_date' => $data['start_date'],
            'end_date' => $data['end_date'],
            'working_days' => $data['working_days'],
            'absent_days' => $data['absent_days'],
        ]);
        $addSalary->save();
        return $addSalary;
    }

    public function show($id)
    {
        // TODO: Implement show() method.
    }

    public function edit($id)
    {
        $salary = Salary::find($id);
        return $salary;
    }

    public function update($id, array $data)
    {
//        dd($id);
        if(Salary::where('id',$id)->exists())
        {
            $salary = Salary::find($id);
            $salary->salary = $data['salary'];
            $salary->month = $data['month'];
            $salary->start_date = $data['start_date'];
            $salary->end_date = $data['end_date'];
            $salary->working_days = $data['working_days'];
            $salary->absent_days = $data['absent_days'];
            $salary->save();
            return $salary;
        }
    }

    public function destroy($id)
    {
        $salary = Salary::find($id);
        $salary->delete();
        $salary = Employee::find($salary->employee_id)->Salary;

        return $salary;
    }
}
