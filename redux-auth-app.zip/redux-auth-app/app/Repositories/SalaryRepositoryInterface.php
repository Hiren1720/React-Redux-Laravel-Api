<?php

namespace App\Repositories;

interface SalaryRepositoryInterface
{
    /**
     * @param array $data
     * @return mixed
     */
    public function index(array $data);

    /**
     * @return mixed
     */
    public function create();
    
    /**
     * @return mixed
     */
    public function getAll();
    /**
     * @param array $data
     * @param $id
     * @return mixed
     */
    public function store(array $data,$id);

    /**
     * @param $id
     * @return mixed
     */
    public function show($id);

    /**
     * @param $id
     * @return mixed
     */
    public function edit($id);

    /**
     * @param $id
     * @param array $data
     * @return mixed
     */
    public function update($id,array $data);

    /**
     * @param $id
     * @return mixed
     */
    public function destroy($id);
}
